{
    'name': 'Slide Time Tracking',
    'version': '1.3',  # Aggiornato
    'author': 'ITLand',
    'depends': ['base', 'web', 'website_slides'],
    'data': [
        'views/slide_template.xml',
        'views/slide_time_tracking_views.xml',  # Nuovo file XML aggiunto
    ],
    'installable': True,
    'application': True,
}
