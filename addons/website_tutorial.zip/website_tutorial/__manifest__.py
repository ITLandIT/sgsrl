{
    'name': 'Website Tutorial',
    'description': 'A simple website tutorial module',
    'author': 'Your Name',
    'version': '2.9',
    'depends': ['website'],
    'data': [
        'views/templates.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True
}
