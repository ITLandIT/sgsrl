{
    'name': 'Verifica certificazioni',
    'description': 'Modulo per la verifica dei certificati rilasciati',
    'author': 'ITLand',
    'version': '2.10',
    'depends': ['website'],
    'data': [
        'views/templates.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True
}